import IO from './io';
import Media from './media';

const Actions = {
  IO,
  Media,
};

export default Actions;
