export default {
  appTitle: process.env.REACT_APP_TITLE || 'Argan',
  url: process.env.REACT_APP_BACKEND_URL,
  demo: process.env.REACT_APP_DEMO === 'true',
};
