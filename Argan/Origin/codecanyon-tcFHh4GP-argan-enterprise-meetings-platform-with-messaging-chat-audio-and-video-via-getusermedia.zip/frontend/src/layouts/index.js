import Meeting from './Meeting';

const Layouts = {
  Meeting,
};

export default Layouts;
