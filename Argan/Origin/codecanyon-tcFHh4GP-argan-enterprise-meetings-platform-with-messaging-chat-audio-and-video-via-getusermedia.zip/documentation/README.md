# Argan Documentation

The Argan documentation is available online at https://www.honeyside.it/tag/argan/

On the above page, you will find:
* Versioned application documentation
* News on this item
* Development plans for future updates
